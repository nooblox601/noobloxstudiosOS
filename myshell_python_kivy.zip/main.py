import json, base64, hashlib
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.core.window import Window
from kivy.uix.popup import Popup

def normalize(s):
    if s is None: return ""
    return " ".join(s.strip().lower().split())

def pbkdf2_hash(combined, salt_b64, iterations, dklen):
    salt = base64.b64decode(salt_b64)
    h = hashlib.pbkdf2_hmac("sha256", combined.encode("utf-8"), salt, iterations, dklen)
    return base64.b64encode(h).decode("utf-8")

class ProvaLayout(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', **kwargs)
        self.padding = 10
        self.spacing = 10
        self.questions = [
            "1) 237 + 489 =",
            "2) Simplifique 18/24",
            "3) 20% de 250 =",
            "4) Se 3x + 5 = 20, x =",
            "5) Área retângulo 7 cm e 4 cm =",
            "6) Houveram/Houve muitos alunos na aula. Qual correto?",
            "7) Quem fez a ação? 'O gato subiu no telhado.'",
            "8) 'rápido' é advérbio ou adjetivo?",
            "9) Coloque vírgula: Quando cheguei a festa já tinha começado",
            "10) Dê um sinônimo para 'feliz'",
            "11) Qual órgão bombeia o sangue?",
            "12) Unidade SI de força (sigla)",
            "13) Símbolo químico da água",
            "14) A Terra gira em torno do(a) ____",
            "15) Cite uma forma de prevenção contra resfriados"
        ]
        # load config
        with open("config.json", "r", encoding="utf-8") as f:
            self.config = json.load(f)

        scroll = ScrollView(size_hint=(1,1))
        grid = GridLayout(cols=1, spacing=8, size_hint_y=None)
        grid.bind(minimum_height=grid.setter('height'))

        self.textinputs = []
        for q in self.questions:
            box = BoxLayout(orientation='vertical', size_hint_y=None, height=110)
            box.add_widget(Label(text=q, size_hint_y=None, height=30))
            ti = TextInput(multiline=False, size_hint_y=None, height=70)
            box.add_widget(ti)
            grid.add_widget(box)
            self.textinputs.append(ti)

        scroll.add_widget(grid)
        self.add_widget(scroll)

        btn = Button(text="Enviar respostas / Desbloquear", size_hint=(1,None), height=48)
        btn.bind(on_release=self.on_submit)
        self.add_widget(btn)

    def on_submit(self, instance):
        answers = [normalize(ti.text) for ti in self.textinputs]
        combined = "|".join(answers)
        calc = pbkdf2_hash(combined, self.config["passwordSalt"], self.config["iterations"], self.config["hashByteSize"])
        if calc == self.config["passwordHash"]:
            popup = Popup(title="Sucesso", content=Label(text="Desbloqueado! Acesso concedido."), size_hint=(.6,.4))
            popup.open()
        else:
            popup = Popup(title="Falha", content=Label(text="Respostas incorretas. Acesso negado."), size_hint=(.7,.4))
            popup.open()

class ProvaApp(App):
    def build(self):
        Window.size = (800, 600)
        return ProvaLayout()

if __name__ == "__main__":
    ProvaApp().run()
